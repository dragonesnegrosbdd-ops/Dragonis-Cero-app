/** @type {import('next').NextConfig} */
const nextConfig = {
  env: {
    NEXT_PUBLIC_SUPABASE_URL: "https://armzyzgrnqczeidvwuur.supabase.co",
    NEXT_PUBLIC_SUPABASE_ANON_KEY: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImFybXp5emdybnFjemVpZHZ3dXVyIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjQxMDg4MzEsImV4cCI6MjA3OTY4NDgzMX0.FAXZ8aQywvOe5r0RjpXxAO2H4eL-1Arr6L7u6MUB4ZE",
  },
};

module.exports = nextConfig;
