"use client";

import { useState } from "react";
import { supabase } from "../../../lib/supabaseClient";

export default function RegisterPage() {
  const [email, setEmail] = useState("");
  const [pass, setPass] = useState("");
  const [role, setRole] = useState("parent");
  const [error, setError] = useState("");

  async function register(e) {
    e.preventDefault();
    setError("");

    // crear usuario
    const { data, error } = await supabase.auth.signUp({
      email,
      password: pass,
      options: {
        data: {
          role: role,
        },
      },
    });
    

    if (error) {
      setError(error.message);
      return;
    }

    // guardar metadata
    const userId = data.user.id;

    await supabase.from("users_meta").insert({
      auth_uid: userId,
      email: email,
      role: role,
    });

    alert("Registro exitoso. Ahora puede iniciar sesión.");
    window.location.href = "/login";
  }

  return (
    <div style={{ padding: 40 }}>
      <h1>Registro</h1>

      <form onSubmit={register}>
        <input
          type="email"
          placeholder="Correo"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
        /><br/><br/>

        <input
          type="password"
          placeholder="Contraseña"
          value={pass}
          onChange={(e) => setPass(e.target.value)}
          required
        /><br/><br/>

        <label>Seleccione Rol:</label><br/>
        <select value={role} onChange={(e) => setRole(e.target.value)}>
          <option value="parent">Padre</option>
          <option value="participant">Participante (Joven)</option>
          <option value="instructor">Instructor</option>
          <option value="coordinator">Coordinador</option>
        </select><br/><br/>

        <button type="submit">Registrar</button>
      </form>

      {error && <p style={{ color: "red" }}>{error}</p>}
    </div>
  );
}
