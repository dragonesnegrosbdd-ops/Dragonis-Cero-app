"use client";

import { useState } from "react";
import { supabase } from "../../../lib/supabaseClient";

export default function LoginPage() {
  const [email, setEmail] = useState("");
  const [pass, setPass] = useState("");
  const [error, setError] = useState("");

  async function login(e) {
    e.preventDefault();
    setError("");

    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password: pass,
    });

    if (error) {
      setError(error.message);
      return;
    }

    // Obtener rol desde metadata
    const userId = data.user.id;

    const { data: meta } = await supabase
      .from("users_meta")
      .select("role")
      .eq("auth_uid", userId)
      .single();

    const role = meta?.role || "parent";

    window.location.href = `/dashboard/${role}`;
  }

  return (
    <div style={{ padding: 40 }}>
      <h1>Inicio de Sesión</h1>

      <form onSubmit={login}>
        <input
          type="email"
          placeholder="Correo"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
        /><br/><br/>

        <input
          type="password"
          placeholder="Contraseña"
          value={pass}
          onChange={(e) => setPass(e.target.value)}
          required
        /><br/><br/>

        <button type="submit">Entrar</button>
      </form>

      {error && <p style={{ color: "red" }}>{error}</p>}
    </div>
  );
}
