export default function InstructorDashboard() {
  return (
    <div style={{ padding: 40 }}>
      <h1>Panel del Instructor</h1>
      <p>Gestión de grupos, sesiones, seguimiento y evaluaciones.</p>
    </div>
  );
}
