export default function CoordinatorDashboard() {
  return (
    <div style={{ padding: 40 }}>
      <h1>Panel del Coordinador</h1>
      <p>Acceso total a métricas, reportes, klanes y asignaciones.</p>
    </div>
  );
}
