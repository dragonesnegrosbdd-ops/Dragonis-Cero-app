export default function ParticipantDashboard() {
  return (
    <div style={{ padding: 40 }}>
      <h1>Panel del Participante (Joven)</h1>
      <p>Retos, actividades, progreso y análisis FODA personal.</p>
    </div>
  );
}
