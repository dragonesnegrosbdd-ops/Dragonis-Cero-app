export default function Home() {
  return (
    <main style={{ padding: "40px" }}>
      <h1>Sistema Dragones Negros + Papá Estoico</h1>
      <p>Seleccione una opción:</p>

      <ul>
        <li><a href="/login">Iniciar sesión</a></li>
        <li><a href="/register">Registrarse</a></li>
      </ul>
    </main>
  );
}
