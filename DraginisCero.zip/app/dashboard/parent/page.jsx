export default function ParentDashboard() {
  return (
    <div style={{ padding: 40 }}>
      <h1>Panel del Padre Estoico</h1>
      <p>Bitácoras BCP-3, herramientas FDE-1, POD-1, RFC-2, AID-2.</p>
    </div>
  );
}
